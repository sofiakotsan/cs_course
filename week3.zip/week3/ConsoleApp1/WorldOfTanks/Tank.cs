﻿using System;

namespace WorldOfTanks
{
    public static class MyRand
    {
        private static Random myRand = new Random();
        public static int GetRandNum(int min = Int32.MinValue, int max = Int32.MaxValue)
        {
            return myRand.Next(min, max);
        }
    }
    public class Tank
    {
        private string name;
        private int weaponLvl;
        private int armorLvl;
        private int manevrLvl;

        public string Name {get => name; private set
            {
                if (value == null || value == "")
                    throw new Exception("Name can't be empty");
                name = value;
            }
        }
        public string GetWeaponLvl()
        {
            return weaponLvl.ToString();
        }
        public string GetArmorLvl()
        {
            return armorLvl.ToString();
        }
        public string GetManevrLvl()
        {
            return manevrLvl.ToString();
        }
        public Tank(string _name)
        {
            name = _name;
            weaponLvl = MyRand.GetRandNum(0, 100);
            armorLvl = MyRand.GetRandNum(0, 100);
            manevrLvl = MyRand.GetRandNum(0, 100);
        }

        public static bool operator^(Tank t1, Tank t2)
        {
            bool hasBetterWeapon = t1.weaponLvl > t2.weaponLvl;
            bool hasBetterArmor = t1.armorLvl > t2.armorLvl;
            bool hasBetterManevr = t1.manevrLvl > t2.manevrLvl;
            return (hasBetterWeapon ? (hasBetterWeapon && (hasBetterArmor || hasBetterManevr)) : (hasBetterArmor && hasBetterManevr));
        }
    }
}
