﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using WorldOfTanks;

namespace ConsoleApp1
{
    class Program
    {
        static void Main(string[] args)
        {
            int size = 5;
            Tank[] t34Tanks = new Tank[size];
            try
            {
                for (int i = 0; i < size; i++)
                {
                    t34Tanks[i] = new Tank("t34-" + (i + 1));
                }
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
            }

            Tank[] panteraTanks = new Tank[size];
            try
            {
                for (int i = 0; i < size; i++)
                {
                    panteraTanks[i] = new Tank("pantera-" + (i + 1));
                }
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
            }

            for (int i = 0; i < size; i++)
            {
                Console.WriteLine("Winner: " + (t34Tanks[i] ^ panteraTanks[i] ? t34Tanks[i].Name : panteraTanks[i].Name));
            }
        }
    }
}
